A Pen created at CodePen.io. You can find this one at https://codepen.io/ettrics/pen/Jdjdzp.

 Material Design inspired modals. No jQuery required. Responsive. Read the how to on Ettrics.com